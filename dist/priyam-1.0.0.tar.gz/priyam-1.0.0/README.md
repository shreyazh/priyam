# Priyam

A comprehensive Python package for math, physics, computer science and chemistry.

## Installation

```bash
pip install priyam